#!/usr/bin/env python3
import json, os, re, uuid
from collections import defaultdict
from datetime import datetime
from pathlib import Path
import psutil, requests as req
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS

BASE = Path(__file__).resolve().parent
CFG_FILE = BASE/'config.json'
CONFIG = json.loads(CFG_FILE.read_text())
app = Flask(__name__, static_folder=None); CORS(app)
chats, tasks, events = {}, [], []
def log(msg, level='info'):
    events.append({'time':datetime.now().strftime('%H:%M:%S'),'event':msg,'level':level})
    del events[:-200]
def save_cfg(): CFG_FILE.write_text(json.dumps(CONFIG, indent=2))
def vault():
    p=Path(CONFIG.get('vault_path','./vault'))
    if not p.is_absolute(): p=BASE/p
    p=p.resolve(); p.mkdir(parents=True,exist_ok=True); return p
def note_path(note_id):
    clean='/'.join(x for x in note_id.replace('\\','/').split('/') if x not in ('','.', '..'))
    clean=re.sub(r'[^\w/\- ]','_',clean).strip()
    p=(vault()/f'{clean}.md').resolve()
    if vault() not in p.parents: raise ValueError('Invalid note path')
    return p,clean
log('HERMES Mission Control initialized','success')

@app.get('/')
def index(): return send_file(BASE/'index.html')
@app.get('/api/health')
def health(): return jsonify(status='ok',name='Hermes Mission Control',version='1.1.0',timestamp=datetime.now().isoformat())
@app.route('/api/config',methods=['GET','POST'])
def config_api():
    if request.method=='GET':
        return jsonify(default_provider=CONFIG['default_provider'],providers={k:{'name':v['name'],'model':v['model'],'has_key':bool(v.get('api_key')) or k=='hermes_local'} for k,v in CONFIG['providers'].items()},jarvis_system_prompt=CONFIG.get('jarvis_system_prompt',''),vault_path=CONFIG.get('vault_path','./vault'))
    d=request.get_json(silent=True) or {}; pid=d.get('default_provider')
    if pid in CONFIG['providers']: CONFIG['default_provider']=pid
    for k,v in d.get('providers',{}).items():
        if k in CONFIG['providers']:
            for f in ('api_key','model','base_url'):
                if f in v: CONFIG['providers'][k][f]=v[f]
    for f in ('jarvis_system_prompt','vault_path'):
        if f in d: CONFIG[f]=d[f]
    save_cfg(); log('Configuration updated'); return jsonify(status='ok')

@app.post('/api/chat')
def chat():
    d=request.get_json(silent=True) or {}; sid=d.get('session_id','default'); text=str(d.get('message','')).strip(); pid=d.get('provider',CONFIG['default_provider'])
    if not text: return jsonify(error='Message required'),400
    provider=CONFIG['providers'].get(pid)
    if not provider: return jsonify(error='Unknown provider'),400
    history=chats.setdefault(sid,[]); msgs=[{'role':'system','content':CONFIG['jarvis_system_prompt']}]+[{'role':m['role'],'content':m['content']} for m in history[-20:]]+[{'role':'user','content':text}]
    try:
        if pid=='hermes_local':
            r=req.post(provider['base_url'],json={'model':provider['model'],'messages':msgs,'stream':False},timeout=120); r.raise_for_status(); answer=r.json()['message']['content']
        else:
            if not provider.get('api_key'): raise RuntimeError(f"No API key configured for {provider['name']}")
            r=req.post(provider['base_url'],headers={'Authorization':f"Bearer {provider['api_key']}",'Content-Type':'application/json'},json={'model':provider['model'],'messages':msgs,'temperature':.7,'max_tokens':2048},timeout=90); r.raise_for_status(); answer=r.json()['choices'][0]['message']['content']
    except Exception as e:
        answer=f"⚠️ **Connection issue** — {e}\n\nConfigure a provider in Settings, Boss."
        log(f'AI error ({pid}): {e}','error')
    now=datetime.now().isoformat(); history.extend([{'role':'user','content':text,'timestamp':now},{'role':'assistant','content':answer,'timestamp':datetime.now().isoformat()}]); log(f'Chat via {pid}')
    return jsonify(response=answer,provider=pid,timestamp=datetime.now().isoformat())
@app.get('/api/chat/history/<sid>')
def history(sid): return jsonify(chats.get(sid,[]))
@app.route('/api/chat/sessions',methods=['GET','POST'])
def sessions():
    if request.method=='POST': sid=uuid.uuid4().hex[:8]; chats[sid]=[]; return jsonify(id=sid)
    return jsonify([{'id':k,'message_count':len(v),'preview':v[-1]['content'][:80] if v else '','last_time':v[-1]['timestamp'] if v else None} for k,v in chats.items()])
@app.delete('/api/chat/sessions/<sid>')
def del_session(sid): chats.pop(sid,None); return jsonify(status='ok')

@app.get('/api/vault/notes')
def notes():
    q=request.args.get('q','').lower(); out=[]
    for f in vault().rglob('*.md'):
        c=f.read_text(errors='ignore'); rel=f.relative_to(vault()); tags=re.findall(r'#([\w-]+)',c)
        if q and q not in c.lower() and q not in str(rel).lower(): continue
        lines=[x.strip() for x in c.splitlines() if x.strip()]; title=lines[0].lstrip('#').strip() if lines else f.stem
        out.append({'id':str(rel.with_suffix('')).replace('\\','/'),'title':title,'path':str(rel),'tags':sorted(set(tags)),'modified':datetime.fromtimestamp(f.stat().st_mtime).isoformat(),'preview':c[:200]})
    return jsonify(sorted(out,key=lambda x:x['modified'],reverse=True))
@app.get('/api/vault/note/<path:nid>')
def get_note(nid):
    try: p,n=note_path(nid)
    except ValueError:return jsonify(error='Invalid path'),400
    if not p.exists(): return jsonify(error='Not found'),404
    return jsonify(id=n,content=p.read_text(errors='ignore'),filename=p.name,modified=datetime.fromtimestamp(p.stat().st_mtime).isoformat())
@app.route('/api/vault/note',methods=['POST','DELETE'])
def note():
    d=request.get_json(silent=True) or {}
    try:p,n=note_path(str(d.get('id','')))
    except ValueError:return jsonify(error='Invalid path'),400
    if not n:return jsonify(error='No note ID'),400
    if request.method=='DELETE':
        if not p.exists():return jsonify(error='Not found'),404
        p.unlink();log(f'Note deleted: {n}','warn');return jsonify(status='ok')
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(str(d.get('content','')));log(f'Note saved: {n}');return jsonify(status='ok',id=n)
@app.get('/api/vault/tags')
def tags():
    counts=defaultdict(int)
    for f in vault().rglob('*.md'):
        for t in set(re.findall(r'#([\w-]+)',f.read_text(errors='ignore'))): counts[t]+=1
    return jsonify([{'tag':k,'count':v} for k,v in sorted(counts.items(),key=lambda x:-x[1])])
@app.get('/api/vault/graph')
def graph():
    nodes=[]; edges=[]; known=set()
    for f in vault().rglob('*.md'):
        nid=str(f.relative_to(vault()).with_suffix('')).replace('\\','/'); c=f.read_text(errors='ignore'); title=next((x.lstrip('#').strip() for x in c.splitlines() if x.strip()),nid);nodes.append({'id':nid,'label':title[:40],'group':'note'});known.add(nid)
        edges += [{'source':nid,'target':x.replace('.md','')} for x in set(re.findall(r'\[\[([^\]]+)\]\]',c))]
    for e in edges:
        if e['target'] not in known:nodes.append({'id':e['target'],'label':e['target'],'group':'orphan'});known.add(e['target'])
    return jsonify(nodes=nodes,edges=edges)
@app.get('/api/vault/daily')
def daily():
    day=datetime.now().strftime('%Y-%m-%d'); p,n=note_path('daily/'+day)
    if not p.exists():p.parent.mkdir(exist_ok=True);p.write_text(f'# {day}\n\n## Tasks\n- [ ] \n\n## Notes\n\n#daily')
    return jsonify(id=n,date=day,content=p.read_text())

@app.route('/api/tasks',methods=['GET','POST'])
def task_list():
    if request.method=='GET':return jsonify(tasks)
    d=request.get_json(silent=True) or {}; t={'id':uuid.uuid4().hex[:8],'title':str(d.get('title','')).strip(),'done':False,'created':datetime.now().isoformat()};tasks.append(t);log('Task added: '+t['title']);return jsonify(t)
@app.route('/api/tasks/<tid>',methods=['PUT','DELETE'])
def task_item(tid):
    t=next((x for x in tasks if x['id']==tid),None)
    if not t:return jsonify(error='Not found'),404
    if request.method=='DELETE':tasks.remove(t);return jsonify(status='ok')
    t.update({k:v for k,v in (request.get_json(silent=True) or {}).items() if k in ('title','done')});return jsonify(t)
@app.get('/api/log')
def get_log():return jsonify(events[-min(request.args.get('limit',50,type=int),200):])
@app.get('/api/system')
def system():
    mem=psutil.virtual_memory();disk=psutil.disk_usage('/');net=psutil.net_io_counters();boot=datetime.fromtimestamp(psutil.boot_time())
    return jsonify(cpu={'percent':psutil.cpu_percent(.1),'cores':psutil.cpu_count()},memory={'percent':mem.percent,'total_gb':round(mem.total/2**30,1),'used_gb':round(mem.used/2**30,1)},disk={'percent':disk.percent,'total_gb':round(disk.total/2**30,1),'used_gb':round(disk.used/2**30,1)},network={'sent_mb':round(net.bytes_sent/2**20,1),'recv_mb':round(net.bytes_recv/2**20,1)},processes={'count':len(psutil.pids())},uptime=str(datetime.now()-boot).split('.')[0])
if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.getenv('PORT',CONFIG.get('port',5000))),threaded=True)
