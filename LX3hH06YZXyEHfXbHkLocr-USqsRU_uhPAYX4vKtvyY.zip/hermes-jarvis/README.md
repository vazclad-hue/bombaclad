# HERMES Mission Control / J.A.R.V.I.S.

A self-hosted mission-control dashboard with AI chat, system telemetry, tasks, and an Obsidian-compatible Markdown vault.

## Run locally

```bash
python -m pip install -r requirements.txt
python server.py
```

Open <http://localhost:5000> and configure an AI provider in **Settings**.

## Providers

- Groq
- OpenRouter
- Ollama / Hermes (local)

API keys are not committed. Add yours through Settings after launch.

## Production launch

### Docker

```bash
docker build -t hermes-jarvis .
docker run --rm -p 5000:5000 -v hermes-vault:/app/vault hermes-jarvis
```

### Gunicorn

```bash
PORT=5000 gunicorn --workers 2 --threads 4 --timeout 120 --bind 0.0.0.0:$PORT server:app
```

A `render.yaml` blueprint and `Procfile` are included for cloud deployment. Keep API keys out of Git; configure them after deployment through the Settings panel.
